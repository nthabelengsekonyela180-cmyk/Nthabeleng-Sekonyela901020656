const mysql = require("mysql2");

const db = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "cathryn.",
    database: "library_db"
});

db.connect((error) => {

    if (error) {

        console.log("Database connection failed:");
        console.log(error.message);

    } else {

        console.log("Connected to MySQL!");

    }

});


module.exports = db;