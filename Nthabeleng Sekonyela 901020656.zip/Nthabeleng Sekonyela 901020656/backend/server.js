const express= require("express");
const app=express();
const PORT=3000;

app.use(express.json());

app.get("/",(req,res)=>{
    res.send("library Backend is working");
});

app.get("/api/books",(req,res)=>{
    const sql ="SELECT* FROM books";
    db.query(sql,(error,results)=>{
        if(error){
            res.status(500).json({
                error:error.message
            });
            return;
        }
        res.json(results);
    });
});
app.post("/api/books",(req,res)=>{
    const{
        title,
        author,
        genre,
        isbn,
        quantity
    }=req.body;

    if (!title || !author || !genre || !isbn || quantity === undefined) {

        res.status(400).json({
            error: "Please provide title, author, genre, ISBN and quantity"
        });

        return;
    }
    const sql = `
        INSERT INTO books
        (title, author, genre, isbn, quantity)
        VALUES (?, ?, ?, ?, ?)
    `;

    const values = [
        title,
        author,
        genre,
        isbn,
        quantity
    ];

    db.query(sql, values, (error, result) => {

        if (error) {
            res.status(500).json({
                error: error.message
            });
            return;
        }
        res.status(201).json({
            message: "Book added successfully",
            bookId: result.insertId
        });
    });

});

app.put("/api/books/:id", (req, res) => {
    const bookId = req.params.id;
    const {
        title,
        author,
        genre,
        isbn,
        quantity
    } = req.body;
    const sql = `
        UPDATE books
        SET title = ?,
            author = ?,
            genre = ?,
            isbn = ?,
            quantity = ?
        WHERE id = ?
    `;
    const values = [
        title,
        author,
        genre,
        isbn,
        quantity,
        bookId
    ];
    db.query(sql, values, (error, result) => {
        if (error) {
            res.status(500).json({
                error: error.message
            });
            return;
        }
        if (result.affectedRows === 0) {

            res.status(404).json({
                error: "Book not found"
            });

            return;
        }

        res.json({
            message: "Book updated successfully"
        });

    });

});

app.delete("/api/books/:id", (req, res) => {

    const bookId = req.params.id;
    const sql = "DELETE FROM books WHERE id = ?";

    db.query(sql, [bookId], (error, result) => {

        if (error) {

            res.status(500).json({
                error: error.message
            });

            return;
        }

        if (result.affectedRows === 0) {

            res.status(404).json({
                error: "Book not found"
            });

            return;
        }

        res.json({
            message: "Book deleted successfully"
        });

    });

});

app.listen(PORT, () => {

    console.log(`Server running at http://localhost:${PORT}`);

});
