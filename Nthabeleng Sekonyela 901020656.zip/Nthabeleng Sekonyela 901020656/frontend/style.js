/* ---------------- DATA ---------------- */
let books = JSON.parse(localStorage.getItem("books")) || [];
let users = JSON.parse(localStorage.getItem("users")) || [
  { name: "Catherine", memberId: "catherine", role: "Admin", password: "ad123.." }
];
let transactions = JSON.parse(localStorage.getItem("transactions")) || [];

function saveData() {
  localStorage.setItem("books", JSON.stringify(books));
  localStorage.setItem("users", JSON.stringify(users));
  localStorage.setItem("transactions", JSON.stringify(transactions));
}

/* ---------------- LOGIN ---------------- */
document.getElementById("loginForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const loginId = document.getElementById("loginId").value.trim();
  const loginPassword = document.getElementById("loginPassword").value.trim();
  const message = document.getElementById("loginMessage");

  const user = users.find(u => u.memberId === loginId && u.password === loginPassword);

  if (user) {
    document.getElementById("loginSection").classList.add("hidden");
    document.getElementById("appsection").classList.remove("hidden");
    document.getElementById("WelcomeUser").textContent = `Welcome, ${user.name} (${user.role})`;
    document.getElementById("logoutbutton").textContent = "Logout";
    message.textContent = "";
    showPage("dashboardPage");
    updateDashboard();
  } else {
    message.textContent = "Invalid Membership ID or Password.";
    message.style.color = "red";
  }
});

document.getElementById("logoutbutton").addEventListener("click", function () {
  document.getElementById("appsection").classList.add("hidden");
  document.getElementById("loginSection").classList.remove("hidden");
  document.getElementById("loginForm").reset();
});

/* ---------------- NAVIGATION ---------------- */
const navButtons = document.querySelectorAll(".navButton");
const pages = document.querySelectorAll(".page");

function showPage(pageId) {
  pages.forEach(page => {
    if (page.id === pageId) {
      page.classList.remove("hidden");
    } else {
      page.classList.add("hidden");
    }
  });
}

navButtons.forEach(button => {
  button.addEventListener("click", () => {
    const targetPage = button.getAttribute("data-page") + "Page";
    showPage(targetPage);
    if (targetPage === "dashboardPage") updateDashboard();
    if (targetPage === "transactionPage") renderTransactions();
    if (targetPage === "usersPage") renderUsers();
    if (targetPage === "bookPage") renderBooks();
  });
});

/* ---------------- DASHBOARD ---------------- */
function updateDashboard() {
  document.getElementById("totalBooks").textContent = books.length;
  document.getElementById("totalCopies").textContent = books.reduce((sum, b) => sum + b.quantity, 0);
  document.getElementById("lowStock").textContent = books.filter(b => b.quantity < 2).length;
  document.getElementById("totalUsers").textContent = users.length;

  const tbody = document.getElementById("dashboardBooks");
  tbody.innerHTML = "";
  books.forEach(book => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.genre}</td>
      <td>${book.isbn}</td>
      <td>${book.quantity}</td>
      <td>${book.quantity < 2 ? "Low Stock" : "Available"}</td>
    `;
    tbody.appendChild(row);
  });
}

/* ---------------- BOOKS ---------------- */
function renderBooks() {
  const tbody = document.getElementById("booksTable");
  if (!tbody) return;
  tbody.innerHTML = "";
  books.forEach((book, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.genre}</td>
      <td>${book.isbn}</td>
      <td>${book.quantity}</td>
      <td>
        <button onclick="editBook(${index})">Edit</button>
        <button onclick="deleteBook(${index})">Delete</button>
      </td>
    `;
    tbody.appendChild(row);
  });

  // Update transaction book dropdown
  const select = document.getElementById("transactionBook");
  if (select) {
    select.innerHTML = `<option value="">Select a book</option>`;
    books.forEach((book, i) => {
      const opt = document.createElement("option");
      opt.value = i;
      opt.textContent = book.title;
      select.appendChild(opt);
    });
  }
}

document.getElementById("bookForm")?.addEventListener("submit", e => {
  e.preventDefault();
  const id = document.getElementById("bookID").value;
  const book = {
    title: document.getElementById("bookTitle").value,
    author: document.getElementById("bookAuthor").value,
    genre: document.getElementById("bookGenre").value,
    isbn: document.getElementById("bookISBN").value,
    quantity: parseInt(document.getElementById("bookQuantity").value)
  };
  if (id) {
    books[id] = book;
  } else {
    books.push(book);
  }
  saveData();
  renderBooks();
  e.target.reset();
});

function editBook(index) {
  const book = books[index];
  document.getElementById("bookID").value = index;
  document.getElementById("bookTitle").value = book.title;
  document.getElementById("bookAuthor").value = book.author;
  document.getElementById("bookGenre").value = book.genre;
  document.getElementById("bookISBN").value = book.isbn;
  document.getElementById("bookQuantity").value = book.quantity;
  document.getElementById("booksubmit").textContent = "Update Book";
}

function deleteBook(index) {
  books.splice(index, 1);
  saveData();
  renderBooks();
}

/* ---------------- TRANSACTIONS ---------------- */
function renderTransactions() {
  const tbody = document.getElementById("transactionsTable");
  if (!tbody) return;
  tbody.innerHTML = "";
  transactions.forEach(t => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${t.date}</td>
      <td>${t.book}</td>
      <td>${t.type}</td>
      <td>${t.qty}</td>
    `;
    tbody.appendChild(row);
  });
}

document.getElementById("transactionForm")?.addEventListener("submit", e => {
  e.preventDefault();
  const bookIndex = document.getElementById("transactionBook").value;
  const type = document.getElementById("transactionType").value;
  const qty = parseInt(document.getElementById("transactionQuantity").value);
  if (bookIndex === "") return;
  const book = books[bookIndex];
  if (type === "add") {
    book.quantity += qty;
  } else if (type === "borrow" && book.quantity >= qty) {
    book.quantity -= qty;
  }
  transactions.push({ date: new Date().toLocaleString(), book: book.title, type, qty });
  saveData();
  renderBooks();
  renderTransactions();
  e.target.reset();
});

/* ---------------- USERS ---------------- */
function renderUsers() {
  const tbody = document.getElementById("UsersTable");
  if (!tbody) return;
  tbody.innerHTML = "";
  users.forEach((u, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${u.name}</td>
      <td>${u.memberId}</td>
      <td>${u.role}</td>
      <td>
        <button onclick="deleteUser(${index})">Delete</button>
      </td>
    `;
    tbody.appendChild(row);
  });
}

document.getElementById("Userform")?.addEventListener("submit", e => {
  e.preventDefault();
  const user = {
    name: document.getElementById("userName").value,
    memberId: document.getElementById("Membership").value,
    role: document.getElementById("userRole").value,
    password: document.getElementById("userPassword").value
  };
  users.push(user);
  saveData();
  renderUsers();
  e.target.reset();
});

function deleteUser(index) {
  users.splice(index, 1);
  saveData();
  renderUsers();
}

/* ---------------- INITIAL RENDER ---------------- */
renderBooks();
renderTransactions();
renderUsers();


