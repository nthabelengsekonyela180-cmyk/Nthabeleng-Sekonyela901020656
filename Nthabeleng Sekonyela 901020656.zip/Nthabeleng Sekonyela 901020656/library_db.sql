CREATE DATABASE library_db;
USE library_db;

CREATE TABLE books(
	id INT auto_increment primary key,
    title varchar(255) not null,
    author varchar(255) not null,
    genre varchar(100) not null,
    isbn varchar(50)not null,
    quantity int not null
);

create table user(
	id int auto_increment primary key,
    name varchar(255) not null,
    membership_id varchar(100)unique not null,
    role varchar(50) not null
);

create table transaction(
	id int auto_increment primary key,
    book_id int not null,
    type varchar(50)not null,
    quantity int not null,
    transaction_date timestamp default current_timestamp,
    
    foreign key (book_id)
    references books(id)
    );
